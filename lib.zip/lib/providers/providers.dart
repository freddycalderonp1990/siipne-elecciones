import 'package:flutter/cupertino.dart';
import 'package:provider/provider.dart';
import '../models/models.dart';

part 'userProvider.dart';
part 'recintoProvider.dart';
part 'procesoOperativoProvider.dart';