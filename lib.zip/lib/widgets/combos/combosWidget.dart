
import 'dart:ui';

import 'package:flutter/material.dart';

//import 'package:searchable_dropdown/searchable_dropdown.dart';
import 'package:siipnemovil2/widgets/customWidgets.dart';
import '../../appConfig.dart';
import '../../utils/utils.dart';



part 'comboConBusqueda.dart';
part 'comboSeleccionMultiple.dart';

