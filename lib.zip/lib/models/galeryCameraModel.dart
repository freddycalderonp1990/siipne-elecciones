
part of 'models.dart';
class GaleryCameraModel{

 final String nombreImg;
  final File image;

  GaleryCameraModel({this.nombreImg, this.image});




}